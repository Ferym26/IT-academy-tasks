# simple-boilerplate

A simple set, for a quick start. Try the new features of JavaScript with Babel.

- Babel
- PostCSS
- ESlint

| commands        | actions                |
|-----------------|------------------------|
|`yarn install`   | install                | 
|`yarn run start` | development            |  
|`yarn run build` | production             |
|`yarn run fix`   | fix file with linters  |



