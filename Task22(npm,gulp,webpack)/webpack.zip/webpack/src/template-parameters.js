module.exports = {
  'header': {
    title: 'header parameter',
  },
  'footer': {
    title: 'footer parameter',
  },
  '404': {
    title: 'Not Found',
  },
};
