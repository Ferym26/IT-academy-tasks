﻿'use strict';

const gulp = require('gulp'),
  watch = require('gulp-watch'),
  sass = require('gulp-sass'),
  postcss = require('gulp-postcss'),
  autoprefixer = require('autoprefixer'),
  cssnano = require('cssnano'),
  babel = require('gulp-babel'),
  rimraf = require('rimraf'),
  browserSync = require('browser-sync'),
  preprocess = require('gulp-preprocess'),
  svgInject = require('gulp-inject-svg'),
  reload = browserSync.reload;

const path = {
  build: {   // куда складывать готовый проект
    html: 'wwwroot/',  // путь к проекту
    js: 'wwwroot/js/',  // путь к скриптам
    css: 'wwwroot/css/',  // путь к стилям
    img: 'wwwroot/img/', // путь к картинкам
    fonts: 'wwwroot/fonts/' // путь к шрифтам
  },
  src: { // где лежит проект
    html: 'src/*.html', // файлы страниц
    js: 'src/js/**/*.*', // скрипты
    css: 'src/css/style.scss', // файл стилей, в котором мы подключаем все наши компоненты
    img: 'src/img/**/*.*', // путь к картинкам
    fonts: 'src/fonts/**/*.*' // путь к шрифтам
  },
  watch: { // за какими изменениями будем следить
    html: 'src/**/*.html', 
    js: 'src/**/*.js',
    css: 'src/**/*.scss',
    img: 'src/img/**/*.*',
    svg: 'src/img/**/*.svg',
    fonts: 'src/fonts/**/*.*'
  },
  clean: './wwwroot' // очистка папки с проектом
};

const config = {
  server: {
    baseDir: './wwwroot'  // папка c готовым проектом (для запуска локального сервера)
  },
  host: 'localhost',
  port: 9000,
  logPrefix: 'FD'
};

/***
  Описание задач и действий
***/

//Задача для HTML
gulp.task('html:build', function() {
  gulp
    .src(path.src.html) 
    .pipe(preprocess())  // склейка шаблонов
    .pipe(svgInject({ base: '/src/' })) // инлайним SVG
    .pipe(gulp.dest(path.build.html)) // переписываем в папку build
    .pipe(reload({ stream: true })); // перезагружаем сервер
});
//Задача для CSS
gulp.task('css:build', function() {
  gulp
    .src(path.src.css)
    .pipe(sass().on('error', sass.logError)) // перегнали scss -> css
    .pipe(
      postcss([
        autoprefixer({
          //grid: 'autoplace', // потдержка display:grid в IE (перед использованием почитать мануал)
          browsers: ['last 5 versions', '> 0.5%'] // настройка автопрефиксера
        }),
        cssnano() // сжатие css
      ])
    )
    .pipe(gulp.dest(path.build.css))  // переписываем в папку build
    .pipe(reload({ stream: true }));  // перезагружаем сервер
});
//Задача для Javascript
gulp.task('js:build', function() {
  gulp
    .src(path.src.js)
    .pipe(
      babel({
        presets: ['@babel/preset-env'] // прогоняем через babel
      })
    )
    .pipe(gulp.dest(path.build.js)) // переписываем в папку build
    .pipe(reload({ stream: true })); // перезагружаем сервер
});
//Задача для картинок
gulp.task('image:build', function() {
  gulp
    .src(path.src.img) 
    .pipe(gulp.dest(path.build.img)) 
    .pipe(reload({ stream: true }));
});
//Задача для шрифтов
gulp.task('fonts:build', function() {
  gulp.src(path.src.fonts).pipe(gulp.dest(path.build.fonts));
});

//Cписок тасков для команды build
gulp.task('build', [
  'html:build',
  'js:build',
  'css:build',
  'fonts:build',
  'image:build'
]);
//Cписок тасков для команды watch
gulp.task('watch', function() {
  watch([path.watch.html], function(event, cb) {
    gulp.start('html:build');
  });
  watch([path.watch.svg], function(event, cb) {
    gulp.start('html:build');
  });
  watch([path.watch.css], function(event, cb) {
    gulp.start('css:build');
  });
  watch([path.watch.js], function(event, cb) {
    gulp.start('js:build');
  });
  watch([path.watch.img], function(event, cb) {
    gulp.start('image:build');
  });
  watch([path.watch.fonts], function(event, cb) {
    gulp.start('fonts:build');
  });
});
//Задача для запуска локального сервера
gulp.task('webserver', function() {
  browserSync(config);
});
//Задача по очистке папки с проектом
gulp.task('clean', function(cb) {
  rimraf(path.clean, cb);
});

//Запуск действий по умолчанию
gulp.task('default', ['build', 'webserver', 'watch']);
