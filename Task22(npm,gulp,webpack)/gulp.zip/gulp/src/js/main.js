window.onload = function() {
  console.log( 'Hello WORLD!' );
}