<template>
  <div id="app">
    <nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
          <h1 class="navbar-brand">{{ title }}</h1>
        </div>
      </div>
    </nav>
    <div class="container">
      <div class="row">
        <div class="col-lg-2 col-md-3 col-sm-4">
          <ul class="nav nav-pills nav-stacked">
              <li v-for="(item, index) in places" :key="index" :data-cityID="item.cityID">
                <a href="#"
                  :class="{ 'active': activePlace === index }"
                  v-on:click="activePlace = index; fetchData(item.name, item.cityID)">
                  {{ item.name }}
                </a>
              </li>
          </ul>
        </div>
        <div class="col-lg-10 col-md-9 col-sm-8">
          <Weather
            v-if="!isLoading"
            :weatherData="weatherData"
            :weatherCity="weatherCity"
          />
          <h2 v-else>Загрузка...</h2>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Weather from './components/weather'

export default {
  name: 'App',

  components: {
    Weather
  },

  data () {
    return {
      title: 'Погода, полученная посредством API из сервиса openweathermap',
      places: [
        { name: "Минск",   cityID: "625144" },
        { name: "Гомель",  cityID: "627907" },
        { name: "Брест",   cityID: "629634" },
        { name: "Гродно",  cityID: "627904" },
        { name: "Витебск", cityID: "620127" },
        { name: "Могилев", cityID: "625665" },
      ],
      activePlace: 0,
      isLoading: true,
      weatherData: null,
      weatherCity: null,
    }
  },

  methods: {
    fetchData: function(cityName, cityID) {
      const vm = this,
            apiKey = "5460396124d03105c9daf93bcc5f456a",
            queryURL = "http://api.openweathermap.org/data/2.5/weather?id=" + cityID + "&units=metric&lang=ru&appid=" + apiKey;

      vm.isLoading = true;

      fetch(queryURL).then(response => response.json())
      .then(data => {
        vm.weatherData = data;
        vm.isLoading = false;
        vm.weatherCity = cityName;
      })
      .catch(error => {
        console.error(error);
      });
    },
  },

  mounted() {
    const vm = this;

    vm.fetchData(vm.places[0].name, vm.places[0].cityID);
  },
}
</script>

<style>
  body {
    margin: 0;
    padding: 0;
    font-family: 'Exo 2', -apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen", "Ubuntu", "Cantarell", "Fira Sans", "Droid Sans", "Helvetica Neue", sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

  code {
    font-family: source-code-pro, Menlo, Monaco, Consolas, "Courier New", monospace;
  }

  .navbar-brand {
    font-size: 1.75em;
  }

  .nav-pills {
    flex-direction: column;
  }

  .nav-pills a {
    display: block;
    padding: 8px 15px;
    border-radius: 4px;
    margin-bottom: 10px;
    background-color: var(--blue);
    color: #fff;
    font-size: 1.2em;
    text-decoration: none;
  }

  .nav-pills a:hover {
    background-color: var(--cyan);
    color: #fff;
    text-decoration: none;
  }

  .nav-pills a.active {
    background-color: var(--danger);
    color: #fff;
    text-decoration: none;
  }
</style>
