<template>
  <div class="weather-info">
    <h2 class="weather-title">В городе <span>{{weatherCity}}</span> сейчас <span>{{weatherDescription}}</span>
      <img :src="weatherIcon" :alt="weatherDescription">
    </h2>
    <p>Текущая температура: <strong>{{ weatherData.main.temp }}°C</strong></p>
    <p>Макс. температура: <strong>{{ weatherData.main.temp_max }}°C</strong></p>
    <p>Мин. температура: <strong>{{ weatherData.main.temp_min }}°C</strong></p>
    <p>Ветер дует со скоростью: <strong>{{ weatherData.wind.speed }} м/сек</strong></p>
  </div>
</template>

<script>
export default {
  name: 'Weather',

  props: {
    weatherCity: String,
    weatherData: Object,
  },

  // created() {
  //   console.log(this.weatherCity);
  //   console.log(this.weatherData);
  // },

  computed: {
    weatherDescription() {
      return this.weatherData.weather[0].description;
    },
    weatherIcon() {
      return 'http://openweathermap.org/img/w/' + this.weatherData.weather[0].icon + '.png';
    }
  },
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .weather-title > span {
    text-decoration: underline;
  }

  .weather-title ~ p strong {
    color: var(--success);
    font-size: 1.25em;
    line-height: 1;
  }
</style>
