import React, { Component, Fragment } from 'react';
import "./weather.css";

export default class WeatherDisplay extends Component {
  constructor() {
    super();
    this.state = {
      weatherData: null,
      placeName: null
    };
  }

  componentDidMount() {
    const cityID = this.props.cityID,
          place = this.props.city,
          apiKey = "5460396124d03105c9daf93bcc5f456a",
          queryURL = "http://api.openweathermap.org/data/2.5/weather?id=" + cityID + "&units=metric&lang=ru&appid=" + apiKey;

    this.setState({
      placeName: place
    });

    fetch(queryURL).then(response => response.json())
    .then(data => {
      this.setState({
        weatherData: data
      });
    })
    .catch(error => {
      console.error(error);
    });
  }

  render() {
    const weatherData = this.state.weatherData;
    if (!weatherData) return <h2>Загрузка...</h2>;

    const weather = weatherData.weather[0];
    const iconUrl = "http://openweathermap.org/img/w/" + weather.icon + ".png";

    return (
      <Fragment>
        <h2 className="weather-title">
          В городе <span>{this.state.placeName}</span> сейчас <span>{weather.description}</span>
          <img src={iconUrl} alt={weatherData.description} />
        </h2>
        <p>Температура: <strong>{weatherData.main.temp}°C</strong></p>
        <p>Макс. температура: <strong>{weatherData.main.temp_max}°C</strong></p>
        <p>Мин. температура: <strong>{weatherData.main.temp_min}°C</strong></p>
        <p>Ветер дует со скоростью: <strong>{weatherData.wind.speed} м/сек</strong></p>
      </Fragment>
    );
  }
}
