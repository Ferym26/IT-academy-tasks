import React, { Component } from "react";
import WeatherDisplay from "./weather/weather";
import "bootstrap/dist/css/bootstrap.css";
import "./App.css";

import { Navbar, NavItem, Nav, Grid, Row, Col } from "react-bootstrap";

const PLACES = [
  { name: "Минск",   cityID: "625144" },
  { name: "Гомель",  cityID: "627907" },
  { name: "Брест",   cityID: "629634" },
  { name: "Гродно",  cityID: "627904" },
  { name: "Витебск", cityID: "620127" },
  { name: "Могилев", cityID: "625665" },
];

class App extends Component {
  constructor() {
    super();
    this.state = {
      activePlace: 0,
      title: "Погода, полученная посредством API из сервиса openweathermap",
    };
  }
  render() {
    const activePlace = this.state.activePlace;

    return (
      <div>
        <Navbar>
          <Navbar.Header>
            <Navbar.Brand>
              <h1>{this.state.title}</h1>
            </Navbar.Brand>
          </Navbar.Header>
        </Navbar>
        <Grid>
          <Row>
            <Col lg={2} md={3} sm={4}>
              <Nav
                bsStyle="pills"
                stacked
                activeKey={activePlace}
                onSelect={index => {
                  this.setState({ activePlace: index });
                }}
              >
                {PLACES.map((place, index) => (
                  <NavItem key={index} eventKey={index}>{place.name}</NavItem>
                ))}
              </Nav>
            </Col>
            <Col lg={10} md={9} sm={8}>
              <WeatherDisplay
                key={activePlace}
                cityID={PLACES[activePlace].cityID}
                city={PLACES[activePlace].name}
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

export default App;
